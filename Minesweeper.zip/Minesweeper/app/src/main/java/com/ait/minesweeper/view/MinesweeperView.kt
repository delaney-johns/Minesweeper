package com.ait.minesweeper.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.CompoundButton
import android.widget.ToggleButton
import com.ait.minesweeper.model.MinesweeperModel
import kotlinx.android.synthetic.main.activity_main.view.*
import android.R
import android.widget.Toast
import android.R.id.toggle
import com.ait.minesweeper.MainActivity


class MinesweeperView(context: Context?, attrs: AttributeSet?) : View(context, attrs) {
    var paintBackground: Paint = Paint()
    var paintLine: Paint = Paint()

    var paintText: Paint = Paint()

    init {
        paintBackground.color = Color.BLACK
        paintBackground.style = Paint.Style.FILL

        paintLine.color = Color.WHITE
        paintLine.style = Paint.Style.STROKE
        paintLine.strokeWidth = 7f

        paintText.color = Color.RED
        paintText.textSize = 50f
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        paintText.textSize = height / 5f

    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)

        canvas?.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paintBackground)

        drawBoard(canvas)

        drawPlayers(canvas)

        canvas?.drawText("H", 21f, height / 6f, paintText)

    }

    private fun drawBoard(canvas: Canvas?) {
        // border
        canvas?.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paintLine)
        // four horizontal lines
        canvas?.drawLine(
            0f, (height / 5).toFloat(), width.toFloat(), (height / 5).toFloat(),
            paintLine
        )
        canvas?.drawLine(
            0f, (2 * height / 5).toFloat(), width.toFloat(),
            (2 * height / 5).toFloat(), paintLine
        )
        canvas?.drawLine(
            0f, (3 * height / 5).toFloat(), width.toFloat(),
            (3 * height / 5).toFloat(), paintLine
        )
        canvas?.drawLine(
            0f, (4 * height / 5).toFloat(), width.toFloat(),
            (4 * height / 5).toFloat(), paintLine
        )
        // four vertical lines
        canvas?.drawLine(
            (width / 5).toFloat(), 0f, (width / 5).toFloat(), height.toFloat(),
            paintLine
        )
        canvas?.drawLine(
            (2 * width / 5).toFloat(), 0f, (2 * width / 5).toFloat(), height.toFloat(),
            paintLine
        )
        canvas?.drawLine(
            (3 * width / 5).toFloat(), 0f, (3 * width / 5).toFloat(), height.toFloat(),
            paintLine
        )
        canvas?.drawLine(
            (4 * width / 5).toFloat(), 0f, (4 * width / 5).toFloat(), height.toFloat(),
            paintLine
        )
    }

    private fun drawPlayers(canvas: Canvas?) {
        for (i in 0..4) {
            for (j in 0..4) {
                if (MinesweeperModel.getFieldContent(i, j) == MinesweeperModel.CIRCLE) {
                    val centerX = (i * width / 5 + width / 10).toFloat()
                    val centerY = (j * height / 5 + height / 10).toFloat()
                    val radius = height / 11 - 4

                    canvas?.drawCircle(centerX, centerY, radius.toFloat(), paintLine)
                } else if (MinesweeperModel.getFieldContent(i, j) == MinesweeperModel.CROSS) {
                    canvas?.drawLine(
                        (i * width / 5).toFloat(), (j * height / 5).toFloat(),
                        ((i + 1) * width / 5).toFloat(),
                        ((j + 1) * height / 5).toFloat(), paintLine
                    )

                    canvas?.drawLine(
                        ((i + 1) * width / 5).toFloat(), (j * height / 5).toFloat(),
                        (i * width / 5).toFloat(), ((j + 1) * height / 5).toFloat(), paintLine
                    )
                }
            }
        }
    }



    override fun onTouchEvent(event: MotionEvent?): Boolean {
        val toggle: ToggleButton = findViewById(com.ait.minesweeper.R.id.toggleBtn)
        Log.d("ERROR_HERE", "MY_MESSAGE")
        if (event?.action == MotionEvent.ACTION_DOWN) {

            val tX = event.x.toInt() / (width / 5)
            val tY = event.y.toInt() / (height / 5)

            if (tX < 5 && tY < 5 &&
                MinesweeperModel.getFieldContent(tX, tY) == MinesweeperModel.EMPTY
            ) {
                //determine which to draw here
                //  MinesweeperModel.setFieldContent(tX, tY, 1)
//this new part crashes
               toggle.setOnCheckedChangeListener { _, isChecked ->
                    if (isChecked) {
                        //MinesweeperModel.setFieldContent(tX, tY, 1)

                    } else {
                        // MinesweeperModel.setFieldContent(tX, tY, 2)
                    }
                }
            }

            invalidate()

            // (context as MainActivity).showText(context.getString(R.string.text_next))

        }
        return true
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = View.MeasureSpec.getSize(widthMeasureSpec)
        val h = View.MeasureSpec.getSize(heightMeasureSpec)
        val d = if (w == 0) h else if (h == 0) w else if (w < h) w else h
        setMeasuredDimension(d, d)
    }


}
